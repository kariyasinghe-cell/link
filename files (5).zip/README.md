# Python Tanzu/Harbor CI/CD Pipeline

GitHub Actions reusable-workflow stack for Python services, mirroring the existing
Maven/Tanzu pipeline. Same DAG, same gating logic, same self-hosted runners,
same Harbor + ArgoCD flow — only the language-specific stages are rewritten.

## Files in this drop

| File | Purpose | Counterpart in Maven pipeline |
|------|---------|-------------------------------|
| `dev-tanzu-python-harbor-deploy.yaml` | **Orchestrator** — top-level workflow consumed by service repos | `dev-tanzu-maven-harbor-deploy.yaml` |
| `build-and-test-python.yaml`          | venv → install → `pytest --cov` → `coverage.xml` + `test-results.xml` | `build-and-test-java.yaml` |
| `sonarqube-quality-check-python.yaml` | `sonar-scanner` CLI scan with quality-gate wait | `sonarqube-quality-check-java.yaml` |
| `opensource-license-scan-python.yaml` | `pip download` of all dists + ScanCode + push to results repo | `opensource-license-scan-java.yaml` |

All other reusable workflows (`prepare-workspace`, `prepare-manifests`,
`verify-release-version`, `verify-github-release`, `fetch-repo-topics`,
`harbor-repository-check`, `artifact-release`, `argo-deploy-dev`,
`argo-post-deploy-verify`, `pre-deploy-notify-dev`, `post-deploy-notify-dev`,
`cleanup-workspace`, `cleanup-docker`) are **language-agnostic** and reused
unchanged from the central repo.

## Tooling translation

| Concern               | Maven (Java)                          | Python equivalent used here                          |
|-----------------------|---------------------------------------|------------------------------------------------------|
| Build                 | `mvn -B clean verify`                 | `python -m build` (sdist + wheel)                    |
| Unit tests            | Surefire / `mvn verify`               | `pytest`                                             |
| Coverage              | JaCoCo XML                            | `pytest-cov` → `coverage.xml` (Cobertura)            |
| Test report           | Surefire reports                      | `--junitxml=test-results.xml`                        |
| Code formatting       | Spotless (`mvn spotless:check`)       | Black + isort (`--profile black`)                    |
| SonarQube scanner     | `mvn sonar:sonar`                     | `sonar-scanner` CLI (Java 17)                        |
| Coverage feed to Sonar| `sonar.coverage.jacoco.xmlReportPaths`| `sonar.python.coverage.reportPaths=coverage.xml`     |
| Dependency snapshot   | `mvn dependency:copy-dependencies`    | `pip download --dest target/dependency-dists`        |
| Per-dep metadata      | `META-INF/maven/*/pom.xml`            | `*.dist-info/METADATA` (wheels) / `PKG-INFO` (sdist) |
| Version detection     | `<java.version>` in `pom.xml`         | `requires-python` in `pyproject.toml` / `.python-version` |

## Project conventions assumed

The `build-and-test` and `sonar` workflows expect a reasonably modern Python
service layout. Any one of the following is sufficient:

- `pyproject.toml` with `requires-python = ">=3.x"` and (optionally) a `[project.optional-dependencies] test = [...]` extras group
- `requirements.txt` (+ optional `requirements-test.txt`)
- `setup.py`

Source code is auto-detected as `src/` if present, otherwise the project root.
Tests must live under `tests/`. Both can be overridden via `[tool.coverage.run]`
and `[tool.pytest.ini_options]` in `pyproject.toml`.

## Gating logic — preserved from the Java pipeline

`sonarqube-quality-gate-check` and `opensource-license-scan` continue to skip
themselves when **all three** of these are true (i.e. brand-new repo where
formatting/copyright haven't been retrofitted yet):

```
needs.fetch-repo-topics.outputs.topic_status == 'new'
&& needs.copyright-check.outputs.copyright_failed == 'true'
&& needs.code-formatting-check.outputs.formatting_failed == 'true'
```

The `if:` expression is identical to the Maven version — only the upstream
formatter changed (Spotless → Black/isort).

## Caller usage

Service repos invoke the pipeline exactly as they do for Java today:

```yaml
# .github/workflows/dev-deploy.yaml in a service repo
name: Dev Deploy

on:
  workflow_dispatch:
    inputs:
      release-version:
        required: true
        type: string

jobs:
  call:
    uses: sampathbankplc/devops-central-repository/.github/workflows/dev-tanzu-python-harbor-deploy.yaml@common-workflows
    with:
      environment: dev
      release-version: ${{ inputs.release-version }}
      cluster-namespace: my-namespace
      harbor-project-name: my-project
      manifests-repo: sampathbankplc/my-service-manifests
      base-project: my-service
      cluster-ip: 10.x.x.x
    secrets: inherit
```

## One-time central setup needed

1. Add `.licenserc-python.yaml` to `sampathbankplc/license-copyright-headers`
   (the orchestrator pulls it the same way the Java one pulls
   `.licenserc-java.yaml`).
2. Drop the four files above into
   `sampathbankplc/devops-central-repository/.github/workflows/` on the
   `common-workflows` branch.
3. Sonar project keys are derived from the repo basename — same scheme as Java,
   no per-repo config required.
